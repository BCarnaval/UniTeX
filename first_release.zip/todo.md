## TODO list

<!-- 1. Développer un premier Makefile. -->

2. Fabriquer un template ReVTeX, Homework, Classic
3. Développer un Makefile général.
4. Faire un README.md.
